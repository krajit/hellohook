<?php

namespace local_hellohook;

use core\hook\output\after_standard_main_region_html_generation;

class callbacks {
    public static function inject_hello_message_new(after_standard_main_region_html_generation $hook): void {
        $hook->add_html('<div style="color:green !important;font-weight:bold;padding:1em;">Hello from hook!</div>');
    }
}
